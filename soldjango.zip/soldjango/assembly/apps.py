from django.apps import AppConfig


class AssemblyConfig(AppConfig):
    name = 'assembly'
